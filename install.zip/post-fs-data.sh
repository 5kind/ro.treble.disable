resetprop -n ro.treble.enabled false
