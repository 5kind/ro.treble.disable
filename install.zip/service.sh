resetprop -n ro.treble.enabled true
